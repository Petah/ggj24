export function logInfo(...args: any[]) {
    console.log(...args);
}
