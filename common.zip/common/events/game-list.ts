import { EventType, IEvent } from '../event';

export class GameListRequest implements IEvent {
    public type = EventType.GAME_LIST_REQUEST;
}

export class GameListResponse implements IEvent {
    public type = EventType.GAME_LIST_RESPONSE;
    constructor(public games: {
        name: string;
        players: string[];
    }[]) { }
}
