import { EventType, IEvent } from '../event';

export class JoinGameRequest implements IEvent {
    public type = EventType.JOIN_GAME_REQUEST
    constructor(
        public playerName: string,
        public gameName: string,
    ) { }
}

export class JoinGameResponse implements IEvent {
    public type = EventType.JOIN_GAME_RESPONSE;
    constructor() { }
}
